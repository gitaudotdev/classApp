# classApp

Simple Timetable App for students
