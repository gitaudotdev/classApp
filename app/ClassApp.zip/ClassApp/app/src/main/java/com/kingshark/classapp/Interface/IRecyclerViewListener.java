package com.kingshark.classapp.Interface;

import android.view.View;

public interface IRecyclerViewListener {
    void onClick(View view, int position);
}
